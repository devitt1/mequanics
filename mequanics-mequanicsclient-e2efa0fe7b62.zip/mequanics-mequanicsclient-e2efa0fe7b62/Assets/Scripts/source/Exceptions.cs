
namespace ex
{
	
	
public class InvalidValue : System.Exception
{
}

public class WindowError : System.Exception
{
//	public WindowError(string s)
//	{
//		this.runtime_error = s;
//	}
}

}
