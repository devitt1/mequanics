
public static class QConfig 
{
	public const string s_version = "v2.0";
	public const string s_versionComplete = "v2.0.2";
		
//	public static string s_urlUserDefault = "www.klausbruegmann.de/heap/qblocks/";
//	public static string s_urlUserDefault = "http://www.mequanics.com/";
	public static string s_urlUserDefault = "";
	
//	public static string s_urlExitWebApp = "www.mequanics.com";
	public static string s_urlProjectWebsite = "www.mequanics.com";
	
	public const string s_titleApp = "meQuanics";
	public const string s_titleCompany2 = "Zentrifuge";
	public const string s_titleCompany1 = "NII";
	public const string s_titleCompany3 = "EdernGray";
	
}