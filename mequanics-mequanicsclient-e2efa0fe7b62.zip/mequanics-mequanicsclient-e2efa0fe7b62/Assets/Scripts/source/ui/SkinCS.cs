using UnityEngine;
using System.Collections;

public class SkinCS : MonoBehaviour 
{
	public GUISkin Skin;
}
